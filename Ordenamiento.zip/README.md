# ordenamiento-P3P1
ordenamiento-P3P1
</br>
Complete los metodos de ordenamiento tanto para estructuras estaticas y dinamicas, puede utilizar las APIs de Collection y ArrayList de java.util
